//
//  LuckyBiteTestIOSUIKitTests.swift
//  LuckyBiteTestIOSUIKitTests
//
//  Created by 전해동 on 2/3/25.
//

import Testing
@testable import LuckyBiteTestIOSUIKit

struct LuckyBiteTestIOSUIKitTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
